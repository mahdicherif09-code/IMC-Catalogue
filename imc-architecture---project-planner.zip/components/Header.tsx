import React from 'react';
import { ViewState } from '../types';

interface HeaderProps {
  selectionCount: number;
  onNavigateHome: () => void;
  currentView: ViewState;
}

const Header: React.FC<HeaderProps> = ({ selectionCount, onNavigateHome, currentView }) => {
  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md px-4 py-4 shadow-lg border-b border-gray-100">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
        {/* Logo Section */}
        <div className="flex items-center gap-4 flex-1 w-full md:w-auto">
          <img 
            src="https://www.interior-modelling-concept.com/logo.png" 
            alt="IMC Logo" 
            className="w-16 h-auto object-contain"
            onError={(e) => { e.currentTarget.style.display = 'none'; }} 
          />
          <div className="flex flex-col">
            <h1 className="text-2xl font-bold text-[#1a2a6c] tracking-wide">IMC - Architecture</h1>
            <p className="text-sm text-gray-500 font-light">Conception d'espaces & Décoration</p>
          </div>
        </div>

        {/* Contact & Breadcrumb */}
        <div className="flex flex-col items-end gap-2 w-full md:w-auto">
          <div className="flex flex-col text-right text-sm">
            <span className="font-semibold text-[#1a2a6c] text-xs tracking-wider uppercase mb-0.5">STUDIO PARIS</span>
            <a href="mailto:contact@interior-modelling-concept.com" className="text-gray-600 hover:text-[#1a2a6c] transition-colors">contact@interior-modelling-concept.com</a>
            <a href="tel:+33184180240" className="text-gray-600 hover:text-[#1a2a6c] transition-colors">+33 1 84 18 02 40</a>
          </div>

          <div className="flex items-center gap-2 text-sm text-gray-500 mt-2">
            <button 
              onClick={onNavigateHome} 
              className={`hover:text-[#1a2a6c] transition-colors ${currentView === 'rooms' ? 'font-bold text-[#1a2a6c]' : ''}`}
            >
              Accueil
            </button>
            {selectionCount > 0 && (
              <>
                <span className="text-gray-300">/</span>
                <span className="text-[#1a2a6c] font-medium">{selectionCount} pièce(s)</span>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;