import React from 'react';
import { RoomPatternSvg } from '../constants';
import { Room } from '../types';

interface RoomCardProps {
  room: Room;
  isSelected: boolean;
  selectionOrder: number | null;
  onToggle: (id: number) => void;
}

const RoomCard: React.FC<RoomCardProps> = ({ room, isSelected, selectionOrder, onToggle }) => {
  return (
    <div 
      onClick={() => onToggle(room.id)}
      className={`
        bg-white rounded-2xl overflow-hidden shadow-xl cursor-pointer transition-all duration-300 relative group
        ${isSelected ? 'ring-4 ring-[#1a2a6c] -translate-y-2' : 'hover:-translate-y-3 hover:shadow-2xl'}
      `}
    >
      {/* Badge Selection */}
      {isSelected && selectionOrder !== null && (
        <div className="absolute top-4 right-4 bg-[#1a2a6c] text-white w-8 h-8 rounded-full flex items-center justify-center font-bold z-10 shadow-lg animate-bounce">
          {selectionOrder}
        </div>
      )}
      
      {/* Promo Badge */}
      <div className="absolute top-4 left-4 bg-gradient-to-r from-[#ff6b6b] to-[#ee5a6f] text-white px-3 py-1 rounded-full text-xs font-bold z-10 shadow-md">
        -50%
      </div>

      {/* Image Area */}
      <div className="h-60 bg-gray-5 relative flex items-center justify-center overflow-hidden">
        <div className="w-2/3 opacity-50 group-hover:scale-105 group-hover:opacity-80 transition-all duration-500">
           <RoomPatternSvg type={room.pattern} />
        </div>
        <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-semibold text-[#1a2a6c]">
          ⏱️ {room.duration}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-2xl">{room.icon}</span>
          <h3 className="text-xl font-bold text-gray-800">{room.name}</h3>
        </div>
        <p className="text-gray-500 text-sm mb-4 line-clamp-2 min-h-[2.5em]">{room.description}</p>
        
        {/* Pricing */}
        <div className="flex items-center gap-3 mb-4 p-3 bg-[#f0f7f1] rounded-xl">
          <div className="flex flex-col">
            <span className="text-sm text-gray-400 line-through decoration-red-400">{room.price}€</span>
            <span className="text-xl font-bold text-[#2e7d32]">{room.pricePromo.toFixed(2)}€</span>
          </div>
          <div className="ml-auto bg-white text-[#ff6b6b] border border-[#ff6b6b] px-2 py-1 rounded-lg text-xs font-bold">
            Éco {(room.price - room.pricePromo).toFixed(0)}€
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-2">
          {room.features.map((feature, idx) => (
            <span key={idx} className="bg-gray-100 text-gray-600 px-2 py-1 rounded-md text-xs font-medium">
              {feature}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RoomCard;