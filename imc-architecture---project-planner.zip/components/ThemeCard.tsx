import React from 'react';
import { Theme } from '../types';

interface ThemeCardProps {
  theme: Theme;
  onSelect: (id: number) => void;
}

const ThemeCard: React.FC<ThemeCardProps> = ({ theme, onSelect }) => {
  return (
    <div 
      onClick={() => onSelect(theme.id)}
      className="bg-white rounded-2xl overflow-hidden shadow-xl cursor-pointer hover:-translate-y-3 hover:shadow-2xl transition-all duration-300 group"
    >
      {/* Header */}
      <div className="h-56 bg-gradient-to-br from-[#1a2a6c] to-gray-800 p-8 flex flex-col items-center justify-center text-center text-white relative overflow-hidden">
         {/* Simple decorative circle */}
        <div className="absolute w-64 h-64 bg-white/5 rounded-full -top-10 -right-10 blur-2xl group-hover:bg-white/10 transition-colors" />
        
        <div className="text-6xl mb-4 drop-shadow-md transform group-hover:scale-110 transition-transform duration-300">
          {theme.icon}
        </div>
        <h3 className="text-2xl font-bold relative z-10">{theme.name}</h3>
        <p className="text-sm opacity-90 italic font-light relative z-10 mt-1">"{theme.subtitle}"</p>
      </div>

      {/* Body */}
      <div className="p-8">
        <p className="text-gray-600 text-sm leading-relaxed mb-6 min-h-[4em]">
          {theme.description}
        </p>

        <div className="grid grid-cols-2 gap-4 bg-gray-50 p-4 rounded-xl border border-gray-100">
          <div className="text-xs text-gray-600 font-medium flex items-center gap-1">
             ✨ {theme.ambiance}
          </div>
          <div className="text-xs text-gray-600 font-medium flex items-center gap-1">
             🧱 {theme.materials}
          </div>
          <div className="text-xs text-gray-600 font-medium flex items-center gap-1">
             {theme.lighting}
          </div>
          <div className="text-xs text-gray-600 font-medium flex items-center gap-1">
             {theme.budget}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ThemeCard;