import React from 'react';

const ProcessSteps: React.FC = () => {
  const steps = [
    { num: 1, title: 'Sélection', desc: 'Vos pièces' },
    { num: 2, title: 'Style', desc: 'Vos inspirations' },
    { num: 3, title: 'Brief', desc: 'Envoi du dossier' },
    { num: 4, title: 'Visio', desc: 'Rendez-vous expert' },
  ];

  return (
    <div className="hidden md:flex justify-around bg-white/10 border border-white/20 p-6 rounded-2xl mb-12 backdrop-blur-sm">
      {steps.map((step, index) => (
        <div key={index} className="flex flex-col items-center text-center text-white relative flex-1 group">
          {index < steps.length - 1 && (
            <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 text-2xl opacity-50 hidden lg:block">→</div>
          )}
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center text-xl font-bold mb-3 shadow-inner group-hover:scale-110 transition-transform">
            {step.num}
          </div>
          <div>
            <h4 className="font-medium text-lg mb-1">{step.title}</h4>
            <p className="text-xs opacity-80 uppercase tracking-wider">{step.desc}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ProcessSteps;