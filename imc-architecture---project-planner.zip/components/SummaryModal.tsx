import React, { useState } from 'react';
import { Selection } from '../types';
import { MessageSquare, CalendarCheck, Edit2 } from 'lucide-react';

interface SummaryModalProps {
  isOpen: boolean;
  selections: Selection[];
  onClose: () => void;
  onConfirm: (message: string) => void;
}

const SummaryModal: React.FC<SummaryModalProps> = ({ isOpen, selections, onClose, onConfirm }) => {
  const [userMessage, setUserMessage] = useState('');

  if (!isOpen) return null;

  const totalPrice = selections.reduce((sum, s) => sum + s.room.pricePromo, 0);

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-[#0c1445]/90 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Modal Content */}
      <div className="relative bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="p-8 overflow-y-auto custom-scrollbar">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-[#1a2a6c] mb-2 flex items-center justify-center gap-2">
              <CalendarCheck className="w-8 h-8" />
              Récapitulatif
            </h2>
            <p className="text-gray-500">Votre dossier est prêt. Envoyez ce brief pour planifier votre visioconférence.</p>
          </div>

          <div className="bg-gray-50 rounded-2xl p-6 border border-gray-100 mb-6">
            {selections.map((item, idx) => (
              <div key={idx} className="bg-white p-4 rounded-xl shadow-sm mb-4 last:mb-0 border-l-4 border-[#1a2a6c]">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-[#1a2a6c] text-lg">{idx + 1}. {item.room.icon} {item.room.name}</h4>
                    <p className="text-sm text-gray-600 mt-1">
                      Style: <span className="font-medium">{item.theme.name}</span> • Ambiance: <span className="font-medium">{item.variant.name}</span>
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="block font-bold text-[#2e7d32]">{item.room.pricePromo.toFixed(2)} €</span>
                    <span className="text-xs text-gray-400 line-through">{item.room.price} €</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-green-50 rounded-2xl p-6 text-center mb-6 border border-green-100">
             <p className="text-sm text-green-800 uppercase tracking-widest font-semibold mb-1">Budget Étude (Offre -50%)</p>
             <h3 className="text-4xl font-bold text-[#2e7d32]">{totalPrice.toFixed(2)} €</h3>
          </div>

          <div className="mb-6">
            <label className="block text-[#1a2a6c] font-bold mb-2 flex items-center gap-2">
              <MessageSquare className="w-5 h-5" />
              Vos disponibilités & Questions
            </label>
            <textarea
              value={userMessage}
              onChange={(e) => setUserMessage(e.target.value)}
              placeholder="Indiquez vos disponibilités pour la visio (ex: Lundi matin) ou posez vos premières questions..."
              className="w-full bg-gray-50 border border-gray-200 rounded-xl p-4 min-h-[120px] focus:ring-2 focus:ring-[#1a2a6c] focus:outline-none transition-all resize-y"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button 
              onClick={onClose}
              className="px-6 py-4 rounded-xl bg-gray-100 text-gray-600 font-bold hover:bg-gray-200 transition-colors flex items-center justify-center gap-2"
            >
              <Edit2 className="w-4 h-4" />
              Modifier mes choix
            </button>
            <button 
              onClick={() => onConfirm(userMessage)}
              className="px-6 py-4 rounded-xl bg-[#25d366] text-white font-bold hover:brightness-105 shadow-lg shadow-green-500/30 transition-all flex items-center justify-center gap-2 transform hover:-translate-y-1"
            >
              <span className="text-xl">📱</span>
              Envoyer sur WhatsApp
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SummaryModal;