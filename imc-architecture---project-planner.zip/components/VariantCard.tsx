import React from 'react';
import { Variant } from '../types';

interface VariantCardProps {
  variant: Variant;
  index: number;
  isLastStep: boolean;
  onSelect: (index: number) => void;
}

const VariantCard: React.FC<VariantCardProps> = ({ variant, index, isLastStep, onSelect }) => {
  return (
    <div className="bg-white rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300 flex flex-col h-full">
      {/* Moodboard Header */}
      <div className="h-64 bg-gray-100">
        <div className="w-full h-full grid grid-cols-3 grid-rows-3">
          {variant.colors.slice(0, 9).map((color, i) => {
            // First cell is large 2x2
            const isLarge = i === 0;
            const classes = `flex items-center justify-center border border-white/20 ${isLarge ? 'col-span-2 row-span-2' : ''}`;
            return (
              <div 
                key={i} 
                className={classes} 
                style={{ backgroundColor: color }}
              />
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="p-8 flex flex-col flex-1">
        <div className="flex items-center gap-2 mb-4">
          <span className="text-2xl">{variant.icon}</span>
          <h4 className="text-2xl font-bold text-gray-800">{variant.name}</h4>
        </div>
        
        <p className="text-gray-600 mb-6 leading-relaxed">
          {variant.description}
        </p>

        {/* Palette */}
        <div className="mb-6">
          <h5 className="text-xs uppercase tracking-wider text-gray-400 font-bold mb-3">🎨 Palette</h5>
          <div className="flex gap-3">
            {variant.colors.map((color, i) => (
              <div 
                key={i} 
                className="w-8 h-8 rounded-full border-2 border-gray-100 shadow-sm hover:scale-125 transition-transform cursor-help"
                style={{ backgroundColor: color }}
                title={variant.colorNames[i]}
              />
            ))}
          </div>
        </div>

        {/* Materials */}
        <div className="mb-8">
          <h5 className="text-xs uppercase tracking-wider text-gray-400 font-bold mb-3">✨ Matières</h5>
          <div className="flex flex-wrap gap-2">
            {variant.materials.map((mat, i) => (
              <span key={i} className="bg-gray-50 border border-gray-200 text-gray-600 px-3 py-1 rounded-full text-xs font-medium">
                {mat}
              </span>
            ))}
          </div>
        </div>

        {/* Action Button */}
        <button 
          onClick={() => onSelect(index)}
          className="mt-auto w-full py-4 bg-gradient-to-br from-[#1a2a6c] to-[#0c1445] text-white rounded-full font-bold shadow-lg shadow-blue-900/20 hover:shadow-blue-900/40 hover:-translate-y-1 transition-all flex items-center justify-center gap-2"
        >
          {isLastStep ? '✅ Valider mon projet' : '➡️ Pièce suivante'}
        </button>
      </div>
    </div>
  );
};

export default VariantCard;