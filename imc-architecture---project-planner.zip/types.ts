export interface Room {
  id: number;
  name: string;
  icon: string;
  description: string;
  price: number;
  pricePromo: number;
  duration: string;
  pattern: string;
  features: string[];
}

export interface Theme {
  id: number;
  name: string;
  icon: string;
  subtitle: string;
  description: string;
  tags: string[];
  ambiance: string;
  materials: string;
  lighting: string;
  budget: string;
}

export interface Variant {
  name: string;
  icon: string;
  description: string;
  colors: string[];
  colorNames: string[];
  materials: string[];
  inspirations: string[];
  benefits: string[];
}

export interface Selection {
  room: Room;
  theme: Theme;
  variant: Variant;
}

export type ViewState = 'rooms' | 'themes' | 'variants';