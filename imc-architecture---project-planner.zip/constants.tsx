import React from 'react';
import { Room, Theme, Variant } from './types';

// SVG Patterns Component
export const RoomPatternSvg: React.FC<{ type: string; className?: string }> = ({ type, className }) => {
  const patterns: Record<string, React.ReactElement> = {
    sofa: (
      <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" className={className}>
        <rect x="40" y="80" width="120" height="60" rx="10" fill="#8b7355" opacity="0.7" />
        <rect x="35" y="70" width="130" height="70" rx="15" fill="none" stroke="#1a2a6c" strokeWidth="3" />
      </svg>
    ),
    living: (
      <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" className={className}>
        <rect x="50" y="90" width="100" height="50" rx="5" fill="#c4a484" opacity="0.7" />
        <path d="M 80 140 L 80 160 M 120 140 L 120 160" stroke="#1a2a6c" strokeWidth="4" />
      </svg>
    ),
    dining: (
      <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" className={className}>
        <circle cx="100" cy="100" r="50" fill="none" stroke="#1a2a6c" strokeWidth="3" />
        <circle cx="100" cy="60" r="8" fill="#8b7355" />
        <circle cx="130" cy="80" r="8" fill="#8b7355" />
        <circle cx="130" cy="120" r="8" fill="#8b7355" />
        <circle cx="100" cy="140" r="8" fill="#8b7355" />
        <circle cx="70" cy="120" r="8" fill="#8b7355" />
        <circle cx="70" cy="80" r="8" fill="#8b7355" />
      </svg>
    ),
    kitchen: (
      <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" className={className}>
        <rect x="50" y="60" width="100" height="80" rx="5" fill="#f5f5f5" stroke="#1a2a6c" strokeWidth="2" />
        <rect x="60" y="70" width="35" height="25" rx="2" fill="#87ceeb" opacity="0.5" />
        <rect x="105" y="70" width="35" height="25" rx="2" fill="#87ceeb" opacity="0.5" />
      </svg>
    ),
    door: (
      <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" className={className}>
        <rect x="70" y="40" width="60" height="120" rx="3" fill="#8b7355" stroke="#1a2a6c" strokeWidth="3" />
        <circle cx="110" cy="100" r="4" fill="#daa520" />
      </svg>
    ),
    bath: (
      <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" className={className}>
        <ellipse cx="100" cy="110" rx="60" ry="30" fill="#b0e0e6" opacity="0.6" />
        <path d="M 40 110 Q 40 130 50 135 L 150 135 Q 160 130 160 110" fill="none" stroke="#1a2a6c" strokeWidth="3" />
      </svg>
    ),
    bed: (
      <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" className={className}>
        <rect x="40" y="90" width="120" height="50" rx="5" fill="#c4a484" opacity="0.7" />
        <rect x="40" y="70" width="120" height="20" rx="3" fill="#8b7355" opacity="0.8" />
      </svg>
    ),
    bedroom: (
      <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" className={className}>
        <rect x="50" y="95" width="100" height="40" rx="3" fill="#d3d3d3" opacity="0.7" />
        <rect x="50" y="80" width="100" height="15" rx="2" fill="#8b7355" opacity="0.8" />
      </svg>
    ),
    toys: (
      <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" className={className}>
        <circle cx="70" cy="80" r="15" fill="#ff6b6b" opacity="0.7" />
        <rect x="80" y="110" width="40" height="40" fill="#ffd93d" opacity="0.7" />
      </svg>
    ),
    closet: (
      <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" className={className}>
        <rect x="50" y="50" width="100" height="100" fill="#8b7355" opacity="0.3" stroke="#1a2a6c" strokeWidth="2" />
        <line x1="100" y1="50" x2="100" y2="150" stroke="#1a2a6c" strokeWidth="2" />
      </svg>
    ),
    desk: (
      <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" className={className}>
        <rect x="40" y="90" width="120" height="10" fill="#8b7355" opacity="0.8" />
        <rect x="45" y="100" width="10" height="50" fill="#1a2a6c" opacity="0.7" />
        <rect x="145" y="100" width="10" height="50" fill="#1a2a6c" opacity="0.7" />
      </svg>
    ),
    terrace: (
      <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" className={className}>
        <rect x="40" y="90" width="120" height="60" rx="5" fill="#8fbc8f" opacity="0.5" />
        <rect x="90" y="110" width="20" height="30" fill="#8b4513" opacity="0.7" />
      </svg>
    ),
  };

  return patterns[type] || null;
};

// Data
export const ROOMS: Room[] = [
  { id: 1, name: "Pièce de Vie", icon: "🏡", description: "L'espace central de votre maison.", price: 159, pricePromo: 79.50, duration: "45min", pattern: "sofa", features: ["Séjour", "Salon", "Réception"] },
  { id: 2, name: "Salon", icon: "🛋️", description: "Cocon de confort et de détente.", price: 99, pricePromo: 49.50, duration: "30min", pattern: "living", features: ["Cosy", "TV", "Détente"] },
  { id: 3, name: "Salle à Manger", icon: "🍽️", description: "Lieu de partage et convivialité.", price: 99, pricePromo: 49.50, duration: "30min", pattern: "dining", features: ["Repas", "Famille", "Réception"] },
  { id: 4, name: "Cuisine", icon: "👨‍🍳", description: "Le cœur fonctionnel du foyer.", price: 99, pricePromo: 49.50, duration: "45min", pattern: "kitchen", features: ["Technique", "Design", "Ergonomie"] },
  { id: 5, name: "Entrée", icon: "🚪", description: "La première impression.", price: 79, pricePromo: 39.50, duration: "30min", pattern: "door", features: ["Rangement", "Accueil", "Style"] },
  { id: 6, name: "Salle de Bain", icon: "🛁", description: "Votre espace bien-être.", price: 99, pricePromo: 49.50, duration: "30min", pattern: "bath", features: ["Eau", "Relaxation", "Technique"] },
  { id: 7, name: "Suite Parentale", icon: "💑", description: "Chambre + Dressing + Bain.", price: 159, pricePromo: 79.50, duration: "45min", pattern: "bed", features: ["Luxe", "Intimité", "Complet"] },
  { id: 8, name: "Chambre", icon: "🛏️", description: "Refuge personnel et apaisant.", price: 99, pricePromo: 49.50, duration: "30min", pattern: "bedroom", features: ["Repos", "Calme", "Nuit"] },
  { id: 9, name: "Chambre Enfant", icon: "🎨", description: "Un univers ludique et évolutif.", price: 99, pricePromo: 49.50, duration: "30min", pattern: "toys", features: ["Jeu", "Travail", "Sommeil"] },
  { id: 10, name: "Dressing", icon: "👗", description: "Organisation et élégance.", price: 59, pricePromo: 29.50, duration: "30min", pattern: "closet", features: ["Rangement", "Sur-mesure", "Mode"] },
  { id: 13, name: "Bureau", icon: "💼", description: "Espace productif et inspirant.", price: 99, pricePromo: 49.50, duration: "30min", pattern: "desk", features: ["Télétravail", "Focus", "Pro"] },
  { id: 17, name: "Extérieur", icon: "🌿", description: "Terrasse, Balcon ou Jardin.", price: 139, pricePromo: 69.50, duration: "45min", pattern: "terrace", features: ["Nature", "Détente", "Été"] }
];

export const THEMES: Theme[] = [
  { 
    id: 1, 
    name: "Zen & Nature", 
    icon: "🌿", 
    subtitle: "L'art de la sérénité",
    description: "Un havre de paix inspiré de la nature. Matériaux organiques et lignes douces.", 
    tags: ["Épuré", "Végétal", "Apaisant"],
    ambiance: "🧘 Calme",
    materials: "🪵 Bois brut",
    lighting: "💡 Douce",
    budget: "💰 Moyen"
  },
  { 
    id: 2, 
    name: "Design Moderne", 
    icon: "✨", 
    subtitle: "L'élégance du présent",
    description: "Lignes nettes et sophistication minimaliste pour un intérieur intemporel.", 
    tags: ["Graphique", "Chic", "Net"],
    ambiance: "🎭 Élégant",
    materials: "⚡ Verre & Métal",
    lighting: "💡 Design",
    budget: "💰💰 Élevé"
  },
  { 
    id: 3, 
    name: "Maison de Famille", 
    icon: "🌾", 
    subtitle: "Charme et Authenticité",
    description: "L'esprit campagne chic, chaleureux et accueillant, aux textures reconfortantes.", 
    tags: ["Douceur", "Vintage", "Cosy"],
    ambiance: "🏡 Chaleur",
    materials: "🪨 Pierre",
    lighting: "🕯️ Tamisée",
    budget: "💰 Moyen"
  },
  { 
    id: 4, 
    name: "Scandinave", 
    icon: "❄️", 
    subtitle: "Lumière et Fonction",
    description: "Le style Hygge : simplicité fonctionnelle, bois clairs et luminosité maximale.", 
    tags: ["Lumineux", "Pratique", "Bois"],
    ambiance: "☕ Cocooning",
    materials: "🌲 Bois clair",
    lighting: "☀️ Naturelle",
    budget: "💰 Accessible"
  },
  { 
    id: 7, 
    name: "Prestige", 
    icon: "💎", 
    subtitle: "Le luxe absolu",
    description: "L'excellence des matériaux nobles et du raffinement pour un espace d'exception.", 
    tags: ["Luxe", "Or", "Marbre"],
    ambiance: "👑 Exclusif",
    materials: "🏛️ Nobles",
    lighting: "✨ Cristal",
    budget: "💰💰💰 Premium"
  },
  { 
    id: 8, 
    name: "Industriel", 
    icon: "🏭", 
    subtitle: "Esprit Loft",
    description: "Le caractère brut : métal noir, briques apparentes et grands volumes ouverts.", 
    tags: ["Urbain", "Brut", "Loft"],
    ambiance: "🏙️ Atelier",
    materials: "⚙️ Acier",
    lighting: "💡 Edison",
    budget: "💰 Moyen"
  }
];

export const VARIANTS: Variant[] = [
  { 
    name: "Palette Neutre", 
    icon: "⚪", 
    description: "Harmonie naturelle pour une sérénité absolue et une lumière sublimée.", 
    colors: ["#ffffff", "#f5f5dc", "#d3d3d3", "#c0c0c0", "#a89f91"],
    colorNames: ["Blanc", "Sable", "Gris", "Argent", "Taupe"],
    materials: ["Lin", "Coton", "Laine", "Chêne"],
    inspirations: ["Minimalisme", "Slow Life"],
    benefits: ["Intemporel", "Lumineux", "Apaisant"]
  },
  { 
    name: "Tons Chauds", 
    icon: "☀️", 
    description: "Nuances solaires et enveloppantes pour une atmosphère conviviale.", 
    colors: ["#f5deb3", "#daa520", "#cd853f", "#d2691e", "#8b4513"],
    colorNames: ["Blé", "Or", "Terre", "Ocre", "Caramel"],
    materials: ["Velours", "Cuir", "Terre cuite"],
    inspirations: ["Sud", "Automne"],
    benefits: ["Chaleureux", "Accueillant", "Dynamique"]
  },
  { 
    name: "Caractère", 
    icon: "🎩", 
    description: "Contrastes forts et couleurs profondes pour un style affirmé.", 
    colors: ["#2c3e50", "#e74c3c", "#ecf0f1", "#34495e", "#1a2a6c"],
    colorNames: ["Bleu Nuit", "Rouge", "Blanc", "Ardoise", "Indigo"],
    materials: ["Laiton", "Marbre noir", "Noyer"],
    inspirations: ["Art Déco", "Masculin"],
    benefits: ["Unique", "Théâtral", "Premium"]
  },
  { 
    name: "Végétal", 
    icon: "🌱", 
    description: "Fraîcheur organique et retour aux sources.", 
    colors: ["#8b7355", "#6b8c42", "#c4a484", "#e6d5b8", "#556b2f"],
    colorNames: ["Bois", "Vert", "Sable", "Ivoire", "Olive"],
    materials: ["Rotin", "Plantes", "Jute"],
    inspirations: ["Jungle", "Bohème"],
    benefits: ["Respirant", "Naturel", "Zen"]
  }
];