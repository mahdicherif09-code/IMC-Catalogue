import React, { useState } from 'react';
import { ROOMS, THEMES, VARIANTS } from './constants';
import { Room, Theme, Variant, Selection, ViewState } from './types';
import Header from './components/Header';
import ProcessSteps from './components/ProcessSteps';
import RoomCard from './components/RoomCard';
import ThemeCard from './components/ThemeCard';
import VariantCard from './components/VariantCard';
import SummaryModal from './components/SummaryModal';
import { ArrowLeft } from 'lucide-react';

const App: React.FC = () => {
  // State
  const [view, setView] = useState<ViewState>('rooms');
  const [selectedRooms, setSelectedRooms] = useState<Room[]>([]);
  const [currentSelectionIndex, setCurrentSelectionIndex] = useState(0);
  const [finalSelections, setFinalSelections] = useState<Selection[]>([]);
  const [tempTheme, setTempTheme] = useState<Theme | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Computed
  const currentRoom = selectedRooms[currentSelectionIndex];

  // Logic: Room Selection
  const toggleRoom = (id: number) => {
    const room = ROOMS.find(r => r.id === id);
    if (!room) return;
    
    if (selectedRooms.find(r => r.id === id)) {
      setSelectedRooms(prev => prev.filter(r => r.id !== id));
    } else {
      setSelectedRooms(prev => [...prev, room]);
    }
  };

  const startProcess = () => {
    if (selectedRooms.length === 0) return;
    setCurrentSelectionIndex(0);
    setFinalSelections([]);
    setView('themes');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Logic: Theme Selection
  const selectTheme = (themeId: number) => {
    const theme = THEMES.find(t => t.id === themeId);
    if (theme) {
      setTempTheme(theme);
      setView('variants');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Logic: Variant Selection
  const selectVariant = (variantIndex: number) => {
    if (!currentRoom || !tempTheme) return;
    
    const variant = VARIANTS[variantIndex];
    
    const newSelection: Selection = {
      room: currentRoom,
      theme: tempTheme,
      variant: variant
    };

    const newSelections = [...finalSelections, newSelection];
    setFinalSelections(newSelections);

    if (currentSelectionIndex < selectedRooms.length - 1) {
      setCurrentSelectionIndex(prev => prev + 1);
      setTempTheme(null);
      setView('themes');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setIsModalOpen(true);
    }
  };

  // Logic: Navigation
  const goBack = () => {
    if (view === 'variants') {
      setView('themes');
    } else if (view === 'themes') {
      if (currentSelectionIndex > 0) {
        // Remove last selection and go back to variant of previous room? 
        // Or just go back to start. Simplest is back to rooms for now or just prev step.
        // Let's implement simple back:
        setCurrentSelectionIndex(prev => Math.max(0, prev - 1));
        // We need to pop the last selection if we go back logic strictly
        setFinalSelections(prev => prev.slice(0, -1));
        // If we are at index 0, go to rooms
        if (currentSelectionIndex === 0) {
          setView('rooms');
          setFinalSelections([]);
        }
      } else {
        setView('rooms');
        setFinalSelections([]);
      }
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  
  const resetApp = () => {
    setView('rooms');
    setSelectedRooms([]);
    setFinalSelections([]);
    setCurrentSelectionIndex(0);
    setIsModalOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // WhatsApp Integration
  const sendWhatsApp = (userMessage: string) => {
    let msg = "📅 *DEMANDE DE PROJET IMC*\n\n";
    msg += "Voici les détails de ma pré-sélection :\n\n";
    
    finalSelections.forEach((sel, idx) => {
      msg += `🔹 *PIÈCE ${idx + 1} : ${sel.room.name}*\n`;
      msg += `   - Style : ${sel.theme.name}\n`;
      msg += `   - Ambiance : ${sel.variant.name}\n`;
      msg += `   - Budget : ${sel.room.pricePromo} €\n\n`;
    });
    
    const total = finalSelections.reduce((acc, curr) => acc + curr.room.pricePromo, 0);
    msg += `💰 *TOTAL ESTIMATIF : ${total.toFixed(2)} €*\n\n`;
    
    if (userMessage) {
      msg += `💬 *NOTE :*\n${userMessage}\n\n`;
    }
    
    msg += "Merci de me recontacter pour fixer la visio.";
    
    const encoded = encodeURIComponent(msg);
    const url = `https://wa.me/33618480211?text=${encoded}`;
    
    window.open(url, '_blank');
    setIsModalOpen(false);
    setTimeout(resetApp, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0c1445] to-[#1a2a6c] font-sans text-[#2c2c2c] selection:bg-[#ff6b6b] selection:text-white pb-24">
      <Header 
        selectionCount={selectedRooms.length} 
        onNavigateHome={() => {
          if (view !== 'rooms') {
            if (confirm("Voulez-vous recommencer votre sélection ?")) {
              resetApp();
            }
          }
        }}
        currentView={view}
      />

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* ROOMS VIEW */}
        {view === 'rooms' && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Préparez votre Projet</h2>
              <div className="font-serif-display italic text-2xl text-white/80">"Votre transformation commence ici."</div>
            </div>

            <div className="bg-gradient-to-r from-[#ff6b6b] to-[#ee5a6f] text-white p-6 rounded-2xl text-center shadow-lg shadow-red-500/20 mb-10 transform hover:scale-[1.02] transition-transform">
              <p className="text-lg">✨ OFFRE DE LANCEMENT : -50% sur l'étude de votre projet !</p>
              <span className="block mt-1 font-extrabold text-xl">Préparez votre dossier dès maintenant</span>
            </div>

            <ProcessSteps />

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 mb-24">
              {ROOMS.map(room => (
                <RoomCard 
                  key={room.id}
                  room={room}
                  isSelected={selectedRooms.some(r => r.id === room.id)}
                  selectionOrder={selectedRooms.findIndex(r => r.id === room.id) + 1 || null}
                  onToggle={toggleRoom}
                />
              ))}
            </div>
            
            {/* Sticky Footer for Continue */}
            {selectedRooms.length > 0 && (
              <div className="fixed bottom-8 left-0 right-0 px-4 flex justify-center z-40 animate-in slide-in-from-bottom-10">
                <button 
                  onClick={startProcess}
                  className="bg-gradient-to-r from-[#1a2a6c] to-[#0c1445] text-white py-4 px-8 rounded-full font-bold shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center gap-4 border border-white/20"
                >
                  <span className="text-lg">Choisir le style</span>
                  <span className="bg-white text-[#1a2a6c] w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm">
                    {selectedRooms.length}
                  </span>
                  <span>→</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* THEMES VIEW */}
        {view === 'themes' && currentRoom && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <button 
              onClick={goBack}
              className="mb-8 flex items-center gap-2 text-white/80 hover:text-white bg-white/10 px-4 py-2 rounded-full backdrop-blur-sm hover:bg-white/20 transition-all"
            >
              <ArrowLeft size={16} /> Retour
            </button>

            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-2">
                Quel univers pour : <span className="text-[#ff6b6b]">{currentRoom.name}</span> ?
              </h2>
              <p className="text-white/60">Étape {currentSelectionIndex + 1} sur {selectedRooms.length}</p>
              <div className="font-serif-display italic text-xl text-white/80 mt-2">"Imaginez votre futur intérieur..."</div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {THEMES.map(theme => (
                <ThemeCard key={theme.id} theme={theme} onSelect={selectTheme} />
              ))}
            </div>
          </div>
        )}

        {/* VARIANTS VIEW */}
        {view === 'variants' && currentRoom && tempTheme && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <button 
              onClick={goBack}
              className="mb-8 flex items-center gap-2 text-white/80 hover:text-white bg-white/10 px-4 py-2 rounded-full backdrop-blur-sm hover:bg-white/20 transition-all"
            >
              <ArrowLeft size={16} /> Retour aux styles
            </button>

            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-2">
                Affinez l'ambiance <span className="text-gray-300 mx-2">|</span> {tempTheme.name}
              </h2>
              <div className="font-serif-display italic text-xl text-white/80">"Donnez vie à un espace qui vous ressemble."</div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
              {VARIANTS.map((variant, index) => (
                <VariantCard 
                  key={index}
                  variant={variant}
                  index={index}
                  isLastStep={currentSelectionIndex === selectedRooms.length - 1}
                  onSelect={selectVariant}
                />
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Modal */}
      <SummaryModal 
        isOpen={isModalOpen}
        selections={finalSelections}
        onClose={() => setIsModalOpen(false)}
        onConfirm={sendWhatsApp}
      />
    </div>
  );
};

export default App;